if (Meteor.isClient) {
  AutoForm.setDefaultTemplate('materialize');
}
